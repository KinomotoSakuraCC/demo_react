import React from 'react';

import './index.scss';

function NoDataTip () {
  return (
    <div className="nodatatip-wrapper">
      <span>您还没有添加待办事件</span>
    </div>
  );
}

export default NoDataTip;